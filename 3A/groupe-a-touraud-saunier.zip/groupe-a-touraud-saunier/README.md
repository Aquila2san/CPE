[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/75IuOILC)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21570184)

Binôme composé de :
-SAUNIER Victor
-TOURAUD Dorian
3ETI Groupe A

La clé API de OpenWeatherMap est présente dans le dépot, nous avons jugé inutile de l'enlever puisque le dépot gitHub est privé.

SOURCES DES ICONES:
https://fonts.google.com/
Photo prises de Pixabay, Unsplash

DESTINATIONS:
Bangkok, Thaïlande;
Sydney, Australie;
Saint Petersbourg, Russie;
Salvador, Brésil;
Palawan, Philippines;
Putrajaya, Malaisie;
